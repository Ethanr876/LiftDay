# Design

The look is a coach's lift card taped to the rack: a white card in a grey shell, black for the answers, blue for what you typed, red for one thing only.

## Colors

| Token | Value | Job |
| --- | --- | --- |
| `--shell` | `#e4e7ea` | Page background, like the aluminum whiteboard frame |
| `--board` | `#fbfbf9` | The lift card and inputs |
| `--ink` | `#16181a` | Weights, lift names, primary button |
| `--ink-soft` | `#50565d` | Labels, hints, secondary text |
| `--marker-blue` | `#1f4fb8` | Anything the athlete typed (schemes, inputs), links, focus ring |
| `--marker-red` | `#c8202b` | Top set underline, errors. Never decoration. |
| `--rule` | `#d4d8dc` | Row dividers |

Light theme on purpose: weight rooms are lit with bright overhead fluorescents.

## Type

One family, Archivo (Google Fonts), using its width axis:

- Weights: 800, 70% width, 2.75rem, tabular numbers. The biggest thing on screen.
- Title: 800, 75% width, uppercase.
- Everything else: normal width, 600 to 700 for labels, 1rem base. Inputs are 18px so iPhones don't zoom on focus.

## Layout

- Single column, max 34rem, 1rem side padding.
- Card rows are a fixed 3-column grid (lift + scheme, weight, remove). Columns never move; only values change.
- Tap targets are at least 44px.

## Signature

The heaviest line for each lift gets a hand-drawn red marker underline (inline SVG), drawn once in 420ms. Turned off for reduced motion.

## States

Empty card, lift with no max (links to the maxes tab), invalid input (red border + message), storage blocked (message on the maxes tab), disabled "Clear" when the card is empty.
