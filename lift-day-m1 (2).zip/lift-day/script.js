// Lift Day
// Turns "sets x reps at % of max" into the weight you actually load.
// Three layers: DATA (what we store), RULES (the math and checks), DISPLAY (the page).

// =====================================================================
// DATA: the lifts, the settings, and saving to the browser
// =====================================================================

const LIFTS = [
  { id: "squat", name: "Squat" },
  { id: "bench", name: "Bench" },
  { id: "deadlift", name: "Deadlift" },
  { id: "clean", name: "Power clean" },
];

const ROUND_TO = 5; // lbs: a pair of 2.5s is the smallest jump on a bar

const LIMITS = {
  max: [45, 1500], // a max can't be lighter than the empty bar
  sets: [1, 20],
  reps: [1, 50],
  pct: [1, 120],
};

// localStorage can be blocked (private mode), so never let it crash the page.
function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function save(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

// =====================================================================
// RULES: the math and the input checks (no page code, so tests can run them)
// =====================================================================

// Round to the nearest loadable weight. 236.25 -> 235, 238 -> 240, ties round up.
function roundToLoadable(weight) {
  return Math.round(weight / ROUND_TO) * ROUND_TO;
}

function setWeight(max, pct) {
  return roundToLoadable((max * pct) / 100);
}

// The heaviest weight on the card for each lift (the "top set").
function topWeights(entries, maxes) {
  const tops = {};
  for (const e of entries) {
    const max = maxes[e.lift];
    if (!max) continue;
    const w = setWeight(max, e.pct);
    if (!(e.lift in tops) || w > tops[e.lift]) tops[e.lift] = w;
  }
  return tops;
}

function inRange(value, [low, high]) {
  return value >= low && value <= high;
}

// Returns a list of [field, message] problems. Empty list = OK.
function checkEntry(entry) {
  const problems = [];
  if (!inRange(entry.sets, LIMITS.sets)) problems.push(["sets", "Sets must be 1 to 20."]);
  if (!inRange(entry.reps, LIMITS.reps)) problems.push(["reps", "Reps must be 1 to 50."]);
  if (!inRange(entry.pct, LIMITS.pct)) problems.push(["pct", "Percent must be 1 to 120."]);
  return problems;
}

function isValidMax(value) {
  return inRange(value, LIMITS.max);
}

if (typeof module !== "undefined") {
  module.exports = { roundToLoadable, setWeight, topWeights, checkEntry, isValidMax };
}

// =====================================================================
// DISPLAY: drawing the page and handling taps
// =====================================================================

if (typeof document !== "undefined") {
  let maxes = load("liftday.maxes", {});
  let entries = load("liftday.card", []);

  const $ = (id) => document.getElementById(id);
  const liftName = (id) => LIFTS.find((l) => l.id === id).name;

  $("today").textContent = new Date().toLocaleDateString(undefined, {
    weekday: "short", month: "short", day: "numeric",
  });

  // Tabs
  const tabs = [$("tab-card"), $("tab-maxes")];
  function showTab(tab) {
    for (const t of tabs) {
      const on = t === tab;
      t.setAttribute("aria-selected", on);
      t.tabIndex = on ? 0 : -1;
      $(t.getAttribute("aria-controls")).hidden = !on;
    }
  }
  tabs.forEach((t, i) => {
    t.addEventListener("click", () => showTab(t));
    t.addEventListener("keydown", (e) => {
      if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      const next = tabs[(i + 1) % tabs.length];
      showTab(next);
      next.focus();
    });
  });

  // Lift picker
  $("lift").innerHTML = LIFTS.map((l) => `<option value="${l.id}">${l.name}</option>`).join("");

  // Maxes form
  $("max-fields").innerHTML = LIFTS.map((l) => `
    <div class="max-row">
      <label for="max-${l.id}">${l.name}</label>
      <input id="max-${l.id}" data-lift="${l.id}" type="number" inputmode="numeric"
             min="45" max="1500" placeholder="lbs" value="${maxes[l.id] || ""}">
    </div>`).join("");

  $("max-fields").addEventListener("input", (e) => {
    const input = e.target;
    const value = Number(input.value);
    if (input.value === "") {
      delete maxes[input.dataset.lift];
      input.removeAttribute("aria-invalid");
    } else if (isValidMax(value)) {
      maxes[input.dataset.lift] = value;
      input.removeAttribute("aria-invalid");
    } else {
      input.setAttribute("aria-invalid", "true");
      $("max-status").textContent = "Enter a max between 45 and 1500 lbs.";
      return;
    }
    $("max-status").textContent = save("liftday.maxes", maxes)
      ? "Saved."
      : "Couldn't save on this browser (private mode?). Your card still works until you close it.";
    render();
  });

  // Add to card
  $("add-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const form = e.target;
    const entry = {
      lift: form.lift.value,
      sets: Number(form.sets.value),
      reps: Number(form.reps.value),
      pct: Number(form.pct.value),
    };
    const problems = checkEntry(entry);

    for (const name of ["sets", "reps", "pct"]) form[name].removeAttribute("aria-invalid");
    for (const [name] of problems) form[name].setAttribute("aria-invalid", "true");
    $("add-error").textContent = problems.map((p) => p[1]).join(" ");
    if (problems.length) return;

    entries.push(entry);
    save("liftday.card", entries);
    render();
  });

  // Remove one line, or jump to the maxes tab for a missing max
  $("card").addEventListener("click", (e) => {
    const remove = e.target.closest(".remove");
    if (remove) {
      entries.splice(Number(remove.dataset.index), 1);
      save("liftday.card", entries);
      render();
    }
    const needMax = e.target.closest(".need-max");
    if (needMax) {
      showTab($("tab-maxes"));
      $(`max-${needMax.dataset.lift}`).focus();
    }
  });

  $("clear-card").addEventListener("click", () => {
    entries = [];
    save("liftday.card", entries);
    render();
  });

  const MARKER = `<svg class="marker" viewBox="0 0 100 10" preserveAspectRatio="none" aria-hidden="true">
    <path d="M2 6 C 20 3, 45 8, 65 5 S 92 4, 98 6" /></svg>`;

  const X_ICON = `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor"
    stroke-width="2.25" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>`;

  function render() {
    const tops = topWeights(entries, maxes);
    const marked = {}; // underline only the first top set per lift

    $("card").innerHTML = entries.map((e, i) => {
      const max = maxes[e.lift];
      let right;
      if (max) {
        const w = setWeight(max, e.pct);
        const isTop = w === tops[e.lift] && !marked[e.lift];
        if (isTop) marked[e.lift] = true;
        right = `<span class="weight">${w}${isTop ? MARKER : ""}</span>`;
      } else {
        right = `<button type="button" class="need-max" data-lift="${e.lift}">Add ${liftName(e.lift).toLowerCase()} max</button>`;
      }
      return `<li class="row">
        <div>
          <span class="lift-name">${liftName(e.lift)}</span>
          <span class="scheme">${e.sets} × ${e.reps} at ${e.pct}%</span>
        </div>
        ${right}
        <button type="button" class="remove" data-index="${i}" aria-label="Remove ${liftName(e.lift)} ${e.sets} × ${e.reps} at ${e.pct}%">${X_ICON}</button>
      </li>`;
    }).join("");

    $("empty").hidden = entries.length > 0;
    $("clear-card").disabled = entries.length === 0;
  }

  render();
}
