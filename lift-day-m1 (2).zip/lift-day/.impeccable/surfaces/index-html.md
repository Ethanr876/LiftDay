---
version: 1
slug: "index-html"
primary_target: "index.html"
related_targets: []
---

## Scope
index.html, the whole app (m1). Mode: Operate. Athlete at the rack, phone in one hand, between sets, under weight-room fluorescents.

## Task
Enter maxes once; enter today's workout (lift, sets x reps at %); read every set's loadable weight. States: no maxes yet, a lift with no max, saved/restored from localStorage, invalid input.

## Direction contract
THESIS: The day's lifting reads like the coach's lift card taped to the rack, except every number is already done. Refuses the dark gym-app dashboard with neon accent and ring charts.
OWN-WORLD: White board ground (#fbfbf9) in a cool aluminum-grey shell, marker black for answers, marker blue for what you type, marker red reserved for the top set only. Ruled rows, no cards-in-cards, no shadows.
STORY: Athlete opens the page, sees today's card, reads the weight on the line they're on, loads the bar.
FIRST VIEWPORT: Header bar "Lift Day" + date. Below, the lift card: one block per lift, rows "Set 1 · 5 reps · 75% → 235". Weight is the largest type on screen, right-aligned, tabular. Add-lift control under the card. Maxes live in a second tab.
FORM: Coach's whiteboard lift card, my #1 of 7 (Impeccable's pick, chosen over assigned #4 jersey numerals). Signature move: the top set's weight gets a hand-drawn red marker underline. Raises: fixed columns that never shift, only values change (from split-flap board); one reserved color for one meaning (from orienteering map). seed:dcc9b720bc07bb04
FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance
