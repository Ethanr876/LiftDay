// Run with: node tests/math-test.js
// 20 answers worked out by hand. Rule: nearest 5 lbs, exact ties (x.5) round up.
const { setWeight, roundToLoadable, topWeights } = require("../script.js");

const cases = [
  // [max, %, expected]   hand math
  [315, 75, 235],   // 236.25
  [315, 80, 250],   // 252
  [315, 85, 270],   // 267.75
  [315, 90, 285],   // 283.5
  [225, 70, 160],   // 157.5, a tie, rounds up
  [225, 65, 145],   // 146.25
  [405, 60, 245],   // 243
  [405, 72.5, 295], // 293.625
  [185, 50, 95],    // 92.5, a tie, rounds up
  [185, 100, 185],  // 185
  [500, 77, 385],   // 385
  [275, 82, 225],   // 225.5
  [135, 40, 55],    // 54
  [350, 88, 310],   // 308
  [245, 73, 180],   // 178.85
  [300, 67.5, 205], // 202.5, a tie, rounds up
  [455, 95, 430],   // 432.25
  [200, 105, 210],  // 210
  [160, 55, 90],    // 88
  [380, 62, 235],   // 235.6
];

let failed = 0;
for (const [max, pct, expected] of cases) {
  const got = setWeight(max, pct);
  if (got !== expected) {
    failed++;
    console.log(`FAIL  ${pct}% of ${max}: expected ${expected}, got ${got}`);
  }
}

// The examples written in the project plan
if (roundToLoadable(236) !== 235 || roundToLoadable(238) !== 240) {
  failed++;
  console.log("FAIL  plan examples: 236 -> 235 and 238 -> 240");
}

// Top set = heaviest line per lift; lifts with no max are skipped
const tops = topWeights(
  [{ lift: "squat", pct: 70 }, { lift: "squat", pct: 85 }, { lift: "bench", pct: 75 }],
  { squat: 315 }
);
if (tops.squat !== 270 || "bench" in tops) {
  failed++;
  console.log("FAIL  topWeights:", tops);
}

console.log(failed ? `${failed} check(s) failed` : `All ${cases.length + 2} checks passed`);
process.exit(failed ? 1 : 0);
