// Lift Day
// Turns "sets x reps at % of max" into the weight you actually load.
// Three layers: DATA (what we store), RULES (the math and checks), DISPLAY (the page).

// =====================================================================
// DATA: the lifts, the settings, and saving to the browser
// =====================================================================

const LIFTS = [
  { id: "squat", name: "Squat" },
  { id: "bench", name: "Bench" },
  { id: "deadlift", name: "Deadlift" },
  { id: "clean", name: "Power clean" },
];

const ROUND_TO = 5; // lbs: a pair of 2.5s is the smallest jump on a bar
const BAR = 45; // lbs
const PLATES = [45, 35, 25, 10, 5, 2.5]; // a standard US weight room, heaviest first
const REST_DEFAULT = 90; // seconds

const LIMITS = {
  max: [45, 1500], // a max can't be lighter than the empty bar
  bodyweight: [80, 500],
  sets: [1, 20],
  reps: [1, 50],
  pct: [1, 120],
};

// localStorage can be blocked (private mode), so never let it crash the page.
function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function save(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

// =====================================================================
// RULES: the math and the input checks (no page code, so tests can run them)
// =====================================================================

// Round to the nearest loadable weight. 236.25 -> 235, 238 -> 240, ties round up.
function roundToLoadable(weight) {
  return Math.round(weight / ROUND_TO) * ROUND_TO;
}

function setWeight(max, pct) {
  return roundToLoadable((max * pct) / 100);
}

// The heaviest weight on the card for each lift (the "top set").
function topWeights(entries, maxes) {
  const tops = {};
  for (const e of entries) {
    const max = maxes[e.lift];
    if (!max) continue;
    const w = setWeight(max, e.pct);
    if (!(e.lift in tops) || w > tops[e.lift]) tops[e.lift] = w;
  }
  return tops;
}

function inRange(value, [low, high]) {
  return value >= low && value <= high;
}

// Returns a list of [field, message] problems. Empty list = OK.
function checkEntry(entry) {
  const problems = [];
  if (!inRange(entry.sets, LIMITS.sets)) problems.push(["sets", "Sets must be 1 to 20."]);
  if (!inRange(entry.reps, LIMITS.reps)) problems.push(["reps", "Reps must be 1 to 50."]);
  if (!inRange(entry.pct, LIMITS.pct)) problems.push(["pct", "Percent must be 1 to 120."]);
  return problems;
}

function isValidMax(value) {
  return inRange(value, LIMITS.max);
}

function isValidBodyweight(value) {
  return inRange(value, LIMITS.bodyweight);
}

// Plates to put on EACH side, heaviest first. 235 -> [45, 45, 5].
// Returns [] for an empty bar, null if the weight is lighter than the bar.
function platesPerSide(weight) {
  if (weight < BAR) return null;
  let left = (weight - BAR) / 2;
  const plates = [];
  for (const p of PLATES) {
    while (left >= p) {
      plates.push(p);
      left -= p;
    }
  }
  return plates;
}

// Pound-for-pound: how many times your bodyweight you lift. 315 at 180 -> 1.75.
function bodyweightRatio(max, bodyweight) {
  return Math.round((max / bodyweight) * 100) / 100;
}

// Every set on the card in order, with its weight. Used to find the next set to do.
function allSets(entries, maxes) {
  const sets = [];
  entries.forEach((e, entryIndex) => {
    for (let s = 0; s < e.sets; s++) {
      sets.push({
        entryIndex,
        setIndex: s,
        lift: e.lift,
        reps: e.reps,
        weight: maxes[e.lift] ? setWeight(maxes[e.lift], e.pct) : null,
        done: Boolean(e.done && e.done[s]),
      });
    }
  });
  return sets;
}

function nextSet(entries, maxes) {
  return allSets(entries, maxes).find((s) => !s.done) || null;
}

if (typeof module !== "undefined") {
  module.exports = {
    roundToLoadable, setWeight, topWeights, checkEntry, isValidMax,
    isValidBodyweight, platesPerSide, bodyweightRatio, allSets, nextSet,
  };
}

// =====================================================================
// DISPLAY: drawing the page and handling taps
// =====================================================================

if (typeof document !== "undefined") {
  let maxes = load("liftday.maxes", {});
  let entries = load("liftday.card", []);
  let bodyweight = load("liftday.bodyweight", null);
  let restSeconds = load("liftday.rest", REST_DEFAULT);
  let rest = null; // { endAt, total, over } while resting
  let restTick = null;
  let lastBarKey = null;
  let audio = null;

  // Cards saved before check-offs existed get an empty "done" list
  for (const e of entries) {
    if (!Array.isArray(e.done) || e.done.length !== e.sets) e.done = Array(e.sets).fill(false);
  }

  const $ = (id) => document.getElementById(id);
  const liftName = (id) => LIFTS.find((l) => l.id === id).name;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  $("today").textContent = new Date().toLocaleDateString(undefined, {
    weekday: "short", month: "short", day: "numeric",
  });

  // ---------- Tabs ----------
  const tabs = [$("tab-card"), $("tab-maxes")];
  function showTab(tab) {
    for (const t of tabs) {
      const on = t === tab;
      t.setAttribute("aria-selected", on);
      t.tabIndex = on ? 0 : -1;
      $(t.getAttribute("aria-controls")).hidden = !on;
    }
  }
  tabs.forEach((t, i) => {
    t.addEventListener("click", () => showTab(t));
    t.addEventListener("keydown", (e) => {
      if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      const next = tabs[(i + 1) % tabs.length];
      showTab(next);
      next.focus();
    });
  });

  // ---------- Icons + drawings ----------
  const X_ICON = `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor"
    stroke-width="2.25" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>`;
  const CHECK_ICON = `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor"
    stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>`;

  // Plate sizes in the drawing: [width, height]
  const PLATE_SIZE = { 45: [15, 112], 35: [13, 98], 25: [12, 82], 10: [9, 60], 5: [7, 46], 2.5: [6, 36] };

  function barbellSVG(plates) {
    const mid = 65;
    let left = "", right = "";
    let lx = 104, rx = 296; // plates stack outward from each collar
    plates.forEach((p, i) => {
      const [w, h] = PLATE_SIZE[p];
      const cls = `plate p${String(p).replace(".", "_")}`;
      lx -= w;
      left += `<rect class="${cls}" data-i="${i}" data-side="-1" x="${lx}" y="${mid - h / 2}" width="${w}" height="${h}" rx="2"/>`;
      right += `<rect class="${cls}" data-i="${i}" data-side="1" x="${rx}" y="${mid - h / 2}" width="${w}" height="${h}" rx="2"/>`;
      rx += w;
    });
    return `<svg class="barbell" viewBox="0 0 400 130" role="img" aria-label="Barbell loaded with ${plates.length ? plates.join(", ") + " on each side" : "no plates"}">
      <rect class="sleeve" x="8" y="58" width="96" height="14" rx="3"/>
      <rect class="sleeve" x="296" y="58" width="96" height="14" rx="3"/>
      <rect class="shaft" x="112" y="62" width="176" height="6" rx="3"/>
      <rect class="collar" x="104" y="52" width="8" height="26" rx="2"/>
      <rect class="collar" x="288" y="52" width="8" height="26" rx="2"/>
      ${left}${right}
    </svg>`;
  }

  // Plates slide onto the sleeves, heaviest first (Emil: 200ms ease-out, 40ms stagger)
  function loadPlates(svg) {
    for (const plate of svg.querySelectorAll(".plate")) {
      const side = Number(plate.dataset.side);
      plate.animate(
        reduceMotion
          ? [{ opacity: 0 }, { opacity: 1 }]
          : [{ transform: `translateX(${side * 36}px)`, opacity: 0 }, { transform: "none", opacity: 1 }],
        { duration: 200, delay: Number(plate.dataset.i) * 40, easing: "cubic-bezier(0.23, 1, 0.32, 1)", fill: "backwards" }
      );
    }
  }

  // ---------- The stage (next set, bar, rest timer) ----------
  function renderStage() {
    const stage = $("stage");
    const ns = nextSet(entries, maxes);

    if (entries.length === 0) {
      stage.innerHTML = `<p class="done-msg">Empty card</p>
        <p class="stage-label">Add today's lifts below. Your next set and the plates to load show up here.</p>`;
      lastBarKey = null;
      return;
    }
    if (!ns) {
      stage.innerHTML = `<p class="done-msg">Card's done</p>
        <p class="stage-label">Every set is checked off. Clear the card when you're ready for the next lift day.</p>`;
      lastBarKey = null;
      return;
    }

    const total = entries[ns.entryIndex].sets;
    const label = `<p class="stage-label"><strong>${liftName(ns.lift)}</strong> · set ${ns.setIndex + 1} of ${total} · ${ns.reps} reps</p>`;

    if (ns.weight === null) {
      stage.innerHTML = `${label}
        <button type="button" class="primary need-max-stage" data-lift="${ns.lift}" style="margin-top:1rem">Add your ${liftName(ns.lift).toLowerCase()} max</button>`;
      lastBarKey = null;
      return;
    }

    const plates = platesPerSide(ns.weight);
    const platesText = plates === null
      ? `Lighter than the ${BAR} lb bar. Use a lighter bar or dumbbells.`
      : plates.length === 0
        ? "Just the bar"
        : `Each side: <strong>${plates.join(" + ")}</strong>`;

    stage.innerHTML = `${label}
      <p class="jersey">${ns.weight}<small>LBS</small></p>
      ${barbellSVG(plates || [])}
      <p class="plates-text">${platesText}</p>
      <div id="rest-area">${restHTML()}</div>`;

    const key = `${ns.entryIndex}-${ns.setIndex}-${ns.weight}`;
    if (key !== lastBarKey) loadPlates(stage.querySelector(".barbell"));
    lastBarKey = key;
    updateTimer();
  }

  function restHTML() {
    if (!rest) {
      return `<div class="stage-actions">
        <button type="button" class="primary" id="set-done">Set done, start rest</button>
      </div>`;
    }
    return `<div class="timer">
        <div class="timer-time" id="timer-time"></div>
        <div class="timer-track"><div class="timer-fill" id="timer-fill"></div></div>
        <div class="stage-actions">
          <button type="button" class="secondary" data-rest="-15" aria-label="15 seconds less rest">−15</button>
          <button type="button" class="primary" id="skip-rest">${rest.over ? "Go" : "Skip rest"}</button>
          <button type="button" class="secondary" data-rest="15" aria-label="15 seconds more rest">+15</button>
        </div>
      </div>`;
  }

  // ---------- Rest timer ----------
  function beep() {
    try {
      if (!audio) return;
      for (const start of [0, 0.25]) {
        const osc = audio.createOscillator();
        const gain = audio.createGain();
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0.25, audio.currentTime + start);
        gain.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + start + 0.18);
        osc.connect(gain).connect(audio.destination);
        osc.start(audio.currentTime + start);
        osc.stop(audio.currentTime + start + 0.2);
      }
    } catch { /* sound is a bonus; the screen still says Go */ }
  }

  function startRest() {
    // Phones only allow sound after a tap, so set it up here
    try { audio = audio || new (window.AudioContext || window.webkitAudioContext)(); } catch { audio = null; }
    rest = { endAt: Date.now() + restSeconds * 1000, total: restSeconds, over: false };
    clearInterval(restTick);
    restTick = setInterval(updateTimer, 250);
  }

  function stopRest() {
    rest = null;
    clearInterval(restTick);
  }

  function updateTimer() {
    if (!rest) return;
    const left = Math.max(0, Math.ceil((rest.endAt - Date.now()) / 1000));
    const time = $("timer-time");
    const fill = $("timer-fill");
    if (!time) return;
    time.textContent = left > 0 ? `${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}` : "GO";
    time.classList.toggle("go", left === 0);
    fill.style.transform = `scaleX(${left / rest.total})`;
    if (left === 0 && !rest.over) {
      rest.over = true;
      clearInterval(restTick);
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
      beep();
      $("rest-area").innerHTML = restHTML();
      updateTimer();
    }
  }

  // ---------- The card ----------
  function renderCard() {
    const tops = topWeights(entries, maxes);
    const marked = {};
    const ns = nextSet(entries, maxes);

    $("card").innerHTML = entries.map((e, i) => {
      const max = maxes[e.lift];
      let right;
      if (max) {
        const w = setWeight(max, e.pct);
        const isTop = w === tops[e.lift] && !marked[e.lift];
        if (isTop) marked[e.lift] = true;
        right = `<span class="weight${isTop ? " top" : ""}">${w}</span>`;
      } else {
        right = `<button type="button" class="need-max" data-lift="${e.lift}">Add ${liftName(e.lift).toLowerCase()} max</button>`;
      }
      const chips = e.done.map((done, s) => {
        const isNext = ns && ns.entryIndex === i && ns.setIndex === s;
        return `<button type="button" class="chip${isNext ? " next" : ""}" data-entry="${i}" data-set="${s}"
          aria-pressed="${done}" aria-label="${liftName(e.lift)} set ${s + 1} of ${e.sets}${done ? ", done" : ""}">${done ? CHECK_ICON : s + 1}</button>`;
      }).join("");
      return `<li class="row">
        <div>
          <span class="lift-name">${liftName(e.lift)}</span>
          <span class="scheme">${e.sets} × ${e.reps} at ${e.pct}%</span>
        </div>
        ${right}
        <button type="button" class="remove" data-index="${i}" aria-label="Remove ${liftName(e.lift)} ${e.sets} × ${e.reps} at ${e.pct}%">${X_ICON}</button>
        <div class="chips">${chips}</div>
      </li>`;
    }).join("");

    $("clear-card").disabled = entries.length === 0;
  }

  function render() {
    renderStage();
    renderCard();
    renderRatios();
  }

  function saveCard() { save("liftday.card", entries); }

  function goToMax(lift) {
    showTab($("tab-maxes"));
    $(`max-${lift}`).focus();
  }

  // ---------- Taps on the stage ----------
  $("stage").addEventListener("click", (e) => {
    if (e.target.closest("#set-done")) {
      const ns = nextSet(entries, maxes);
      entries[ns.entryIndex].done[ns.setIndex] = true;
      saveCard();
      if (nextSet(entries, maxes)) startRest();
      render();
    } else if (e.target.closest("#skip-rest")) {
      stopRest();
      render();
    } else if (e.target.closest("[data-rest]")) {
      const change = Number(e.target.closest("[data-rest]").dataset.rest);
      restSeconds = Math.min(600, Math.max(15, restSeconds + change));
      save("liftday.rest", restSeconds);
      if (rest && !rest.over) {
        rest.endAt += change * 1000;
        rest.total = Math.max(1, rest.total + change);
        updateTimer();
      }
    } else if (e.target.closest(".need-max-stage")) {
      goToMax(e.target.closest(".need-max-stage").dataset.lift);
    }
  });

  // ---------- Taps on the card ----------
  $("card").addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (chip) {
      const entry = entries[Number(chip.dataset.entry)];
      const s = Number(chip.dataset.set);
      entry.done[s] = !entry.done[s];
      saveCard();
      if (entry.done[s] && nextSet(entries, maxes)) startRest();
      render();
      return;
    }
    const remove = e.target.closest(".remove");
    if (remove) {
      entries.splice(Number(remove.dataset.index), 1);
      saveCard();
      render();
      return;
    }
    const needMax = e.target.closest(".need-max");
    if (needMax) goToMax(needMax.dataset.lift);
  });

  $("clear-card").addEventListener("click", () => {
    entries = [];
    stopRest();
    saveCard();
    render();
  });

  // ---------- Add to card ----------
  $("lift").innerHTML = LIFTS.map((l) => `<option value="${l.id}">${l.name}</option>`).join("");

  $("add-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const form = e.target;
    const entry = {
      lift: form.lift.value,
      sets: Number(form.sets.value),
      reps: Number(form.reps.value),
      pct: Number(form.pct.value),
    };
    const problems = checkEntry(entry);

    for (const name of ["sets", "reps", "pct"]) form[name].removeAttribute("aria-invalid");
    for (const [name] of problems) form[name].setAttribute("aria-invalid", "true");
    $("add-error").textContent = problems.map((p) => p[1]).join(" ");
    if (problems.length) return;

    entry.done = Array(entry.sets).fill(false);
    entries.push(entry);
    saveCard();
    render();
  });

  // ---------- Maxes, bodyweight, PRs ----------
  $("max-fields").innerHTML = LIFTS.map((l) => `
    <div class="max-row">
      <label for="max-${l.id}">${l.name}</label>
      <input id="max-${l.id}" data-lift="${l.id}" type="number" inputmode="numeric"
             min="45" max="1500" placeholder="lbs" value="${maxes[l.id] || ""}">
      <span class="ratio" id="ratio-${l.id}"></span>
    </div>`).join("");

  $("bodyweight").value = bodyweight || "";

  function renderRatios() {
    for (const l of LIFTS) {
      const span = $(`ratio-${l.id}`);
      span.textContent = bodyweight && maxes[l.id] ? `${bodyweightRatio(maxes[l.id], bodyweight)}× BW` : "";
    }
  }

  function showStatus(saved) {
    $("max-status").textContent = saved
      ? "Saved."
      : "Couldn't save on this browser (private mode?). Your card still works until you close it.";
  }

  $("bodyweight").addEventListener("input", (e) => {
    const value = Number(e.target.value);
    if (e.target.value === "") {
      bodyweight = null;
    } else if (isValidBodyweight(value)) {
      bodyweight = value;
    } else {
      e.target.setAttribute("aria-invalid", "true");
      $("max-status").textContent = "Enter a bodyweight between 80 and 500 lbs.";
      return;
    }
    e.target.removeAttribute("aria-invalid");
    showStatus(save("liftday.bodyweight", bodyweight));
    renderRatios();
  });

  // Remember the old max when you start typing, so we can spot a PR when you finish
  $("max-fields").addEventListener("focusin", (e) => {
    e.target.dataset.before = maxes[e.target.dataset.lift] || "";
  });

  $("max-fields").addEventListener("input", (e) => {
    const input = e.target;
    const value = Number(input.value);
    if (input.value === "") {
      delete maxes[input.dataset.lift];
    } else if (isValidMax(value)) {
      maxes[input.dataset.lift] = value;
    } else {
      input.setAttribute("aria-invalid", "true");
      $("max-status").textContent = "Enter a max between 45 and 1500 lbs.";
      return;
    }
    input.removeAttribute("aria-invalid");
    showStatus(save("liftday.maxes", maxes));
    render();
  });

  $("max-fields").addEventListener("change", (e) => {
    const lift = e.target.dataset.lift;
    const before = Number(e.target.dataset.before);
    const now = maxes[lift];
    if (before && now && now > before) {
      showPR(lift, now, now - before);
      e.target.dataset.before = now;
    }
  });

  let prTimer = null;
  function showPR(lift, max, gain) {
    const banner = $("pr-banner");
    const ratio = bodyweight ? ` · ${bodyweightRatio(max, bodyweight)}× bodyweight` : "";
    banner.innerHTML = `<span class="big">New PR</span>${liftName(lift)} ${max} lbs (+${gain})${ratio}`;
    banner.classList.add("show");
    if (navigator.vibrate) navigator.vibrate(80);
    clearTimeout(prTimer);
    prTimer = setTimeout(() => banner.classList.remove("show"), 3200);
  }

  render();
}
