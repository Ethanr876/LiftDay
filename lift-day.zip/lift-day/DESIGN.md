# Design

Game-day jersey: a deep navy field, your next weight set like a jersey number (white with a gold outline), and gold as the team color for anything you act on.

## Colors

| Token | Value | Job |
| --- | --- | --- |
| `--navy-900` | `#0b1730` | Page background |
| `--navy-800` | `#10213f` | The stage panel, inputs |
| `--navy-700` | `#183059` | Secondary buttons, timer track |
| `--line` | `#2a4475` | Dividers, borders, open set circles |
| `--white` | `#f4f6fa` | Main text, jersey number fill, 45 lb plates |
| `--soft` | `#a9b8d0` | Labels and secondary text |
| `--gold` | `#f3b62a` | Team color: primary buttons, done sets, next set, top set, timer, PR banner |
| `--red` | `#ff7a6e` | Errors only |

## Type

- **Big Shoulders Display** (900): the jersey number, title, timer, big messages. Only for big numbers and short words.
- **Archivo**: everything else. Inputs are 18px so iPhones don't zoom on focus.
- All numbers use tabular figures so columns don't jump.

## Layout (phone first, max 34rem)

1. **Stage:** the next set (lift, set x of y, reps), the jersey number, the loaded barbell, "Each side: ...", then either "Set done, start rest" or the rest timer.
2. **Card:** one row per line of the workout, weight on the right, set circles underneath.
3. **Add to the card** form, then **Clear today's card**, set apart on its own.

Tap targets are at least 44px.

## Signature

The jersey number: `-webkit-text-stroke` in gold with `paint-order: stroke fill`, so the gold sits outside the white like tackle twill.

## Motion (from Emil Kowalski's animate skill)

| What | How | Why |
| --- | --- | --- |
| Plates load onto the bar | WAAPI, slide in 36px + fade, 200ms, `cubic-bezier(0.23, 1, 0.32, 1)`, 40ms stagger heaviest first | Shows the bar changing for the new set |
| Set circles, buttons | `scale(0.94-0.97)` on press, 120ms; color 150ms | Feedback only, these are tapped a lot |
| Rest timer | `scaleX` on the fill, 250ms linear | Constant progress |
| PR banner | slides down 300ms ease-out, leaves the same way after 3.2s | Rare moment, the one celebration |

Reduced motion: plates fade instead of slide, the banner fades, the timer bar jumps.

## States

Empty card, next set's lift has no max, weight lighter than the bar, just the bar, resting, rest over ("GO" + vibrate + beep), card done, invalid input, storage blocked.
